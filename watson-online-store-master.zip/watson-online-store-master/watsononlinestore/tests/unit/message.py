message = {
    "intents": [],
    "entities": [],
    "input": {},
    "output": {
        "text": [
            "Hello! and Welcome to Watson Online Store."
        ],
        "nodes_visited": [
            "Welcome"
        ],
        "log_messages": []
    },
    "context": {
        "conversation_id": "c1dfce32-3e10-446a-8bd5-8455f8ebe24e",
        "system": {
            "dialog_stack": [
                {
                    "dialog_node": "Welcome"
                }
            ],
            "dialog_turn_counter": 1,
            "dialog_request_counter": 1,
            "_node_output_map": {
                "Welcome": [
                    0
                ]
            }
        },
        "get_input": "yes",
        "input_text": "",
        "shopping_cart": "list"
    },
    "type": "customer",
    "email": "scott.dangelo@ibm.com",
    "first_name": "Scott",
    "last_name": "DAngelo",
    "shopping_cart": []
}
